/*
 * calibrations.c
 *
 *  Created on: May 15, 2024
 *      Author: Dylan Fleming
 */
#include "main.h"
#include "switchcases.h"

void calibration(int calibration_mode) {
	switch (calibration_mode) {
		case SHORT_CALIBRATION:
			// Set the switch states
			HAL_GPIO_WritePin(GPIOA, SW1_V1_Pin|SW2_V1_Pin|SW2_V2_Pin|SW3_V2_Pin|SW4_V1_Pin|SW4_V2_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA, SW1_V2_Pin|SW3_V1_Pin, GPIO_PIN_SET);
			// Set the LED states
			HAL_GPIO_WritePin(GPIOB, OPEN_LED_Pin|LOAD_LED_Pin|THRU_LED_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, SHORT_LED_Pin, GPIO_PIN_SET);
			 break;
		case OPEN_CALIBRATION:
			// Set the switch states
			HAL_GPIO_WritePin(GPIOA, SW1_V1_Pin|SW2_V2_Pin|SW3_V2_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA, SW1_V2_Pin|SW2_V1_Pin|SW3_V1_Pin|SW4_V1_Pin|SW4_V2_Pin, GPIO_PIN_SET);
			// Set the LED states
			HAL_GPIO_WritePin(GPIOB, SHORT_LED_Pin|LOAD_LED_Pin|THRU_LED_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, OPEN_LED_Pin, GPIO_PIN_SET);
			break;
		case LOAD_CALIBRATION:
			// Set the switch states
			HAL_GPIO_WritePin(GPIOA, SW1_V1_Pin|SW2_V2_Pin|SW3_V2_Pin|SW4_V2_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA, SW1_V2_Pin|SW2_V2_Pin|SW3_V1_Pin|SW4_V1_Pin, GPIO_PIN_SET);
			// Set the LED states
			HAL_GPIO_WritePin(GPIOB, SHORT_LED_Pin|OPEN_LED_Pin|THRU_LED_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, LOAD_LED_Pin, GPIO_PIN_SET);
			break;
		case THRU_CALIBRATION:
			// Set the switch states
			HAL_GPIO_WritePin(GPIOA, SW1_V1_Pin|SW2_V2_Pin|SW3_V1_Pin|SW4_V1_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA, SW1_V2_Pin|SW2_V1_Pin|SW2_V2_Pin|SW3_V1_Pin|SW4_V2_Pin, GPIO_PIN_SET);
			// Set the LED states
			HAL_GPIO_WritePin(GPIOB, SHORT_LED_Pin|OPEN_LED_Pin|LOAD_LED_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, THRU_LED_Pin, GPIO_PIN_SET);
			break;
		case DUT_MODE:
			// Set the switch states
			HAL_GPIO_WritePin(GPIOA, SW1_V2_Pin|SW2_V1_Pin|SW2_V2_Pin|SW3_V1_Pin|SW4_V1_Pin|SW4_V2_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA, SW1_V1_Pin|SW3_V2_Pin, GPIO_PIN_SET);
			// Set the LED states
			HAL_GPIO_WritePin(GPIOB, SHORT_LED_Pin|OPEN_LED_Pin|LOAD_LED_Pin|THRU_LED_Pin, GPIO_PIN_RESET);
			break;
	}
}


