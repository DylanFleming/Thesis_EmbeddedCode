/*
 * switchcases.h
 *
 *  Created on: May 15, 2024
 *      Author: dylan
 */

#ifndef INC_SWITCHCASES_H_
#define INC_SWITCHCASES_H_

#define SHORT_CALIBRATION 0
#define OPEN_CALIBRATION 1
#define LOAD_CALIBRATION 2
#define THRU_CALIBRATION 3
#define DUT_MODE 4

#define SHORT_MSG "CALSHORT"
#define OPEN_MSG "CALOPEN0"
#define LOAD_MSG "CALLOAD0"
#define THRU_MSG "CALTHRU0"
#define DUT_MSG "DUTTEST0"

void calibration(int calibration_mode);

#endif /* INC_SWITCHCASES_H_ */
